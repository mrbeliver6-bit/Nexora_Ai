// Nexora's editable company knowledge base. Keep secrets and private customer data out of this file.
export const KNOWLEDGE_BASE = `
NEXORA ASSISTANT — STARTER KNOWLEDGE BASE
Version: 1.0. Details marked historical/unconfirmed must be verified before public launch.

1. BRAND AND BUSINESS
- Brand spelling: Nexora.
- Parent brand used in planning: Nexora Partners.
- Watch brand: Nexora Watches.
- Brand phrases previously considered: “Time Perfected”, “Learn Earn Build Grow”, and “Where Tradition Meets Time”.
- Intended model: sales-first business partnerships. Do not describe it as a recruitment-driven MLM.
- Partners promote watches and may earn commissions on qualifying successful sales under the current official rules.
- Never guarantee income, sales, or promotion.

2. ESSENTIAL WATCH — HISTORICAL DETAILS
- Product: Essential, Obsidian Black.
- Previously listed selling price: Rs. 3,650.
- Previously documented total product profit: Rs. 2,285.
- Previously documented partner/affiliate amount: Rs. 1,000 per qualifying sale.
- These details are historical planning notes and must be re-confirmed before public launch.

3. SIGNATURE WATCH — HISTORICAL DETAILS
- Previously listed selling price: Rs. 5,000.
- Colours: Desert Brown, Mist Grey, Midnight Blue, Olive Green.
- Previously documented total product profit: Rs. 3,175.
- Previously documented partner/affiliate amount: Rs. 1,500 per qualifying sale.
- Re-confirm current price, colours, commission and availability before public launch.

4. GRACE WOMEN'S WATCH — HISTORICAL DETAILS
- Previously listed selling price: Rs. 3,900.
- Earlier planning notes mentioned total profit of Rs. 2,436; this is not the same as partner commission.
- Current price, colours, availability and partner commission are unconfirmed. Do not guess them.

5. OTHER PRODUCT CANDIDATES
- Black Skeleton Chronograph and Brown Square Dial were discussed as possible product candidates.
- Current status, retail prices, commissions and availability are unconfirmed.

6. JOINING, DELIVERY AND RETURNS
- Earlier planning described cash on delivery (COD) and a 7-day return policy.
- Confirm the current joining process, eligibility, delivery terms, and exact return/refund conditions with the Nexora team before treating these as final.
- This bot cannot register partners, place orders, check live order status, access Markaz, verify payments, or issue refunds.

7. TRAINING AND PROGRESSION
- Previously documented progression: Trainee → Assistant Executive → Senior Executive → Executive Leader → Manager.
- Trainee status was described as following an initial 3-day training.
- Senior Executive: previously described as requiring 10 sales.
- Executive Leader: previously described as requiring 20 sales.
- Manager: previously described as requiring 40 sales.
- Assistant Executive threshold, whether sales are cumulative, what counts as a qualifying sale, and any additional conditions are unconfirmed. Refer to the Nexora team.

8. SALES ETHICS
- Encourage honest product descriptions and approved marketing materials.
- Never invent features, testimonials, reviews, scarcity, or earnings claims.
- Explain that income depends on qualifying successful sales and current official commission rules.
- Do not pressure people to join or buy.
- Do not reveal supplier costs, internal test-order information, private partner details, or customer records.

9. SUPPORT AND UNKNOWN DETAILS
- Official support contact/link has not been supplied in this knowledge base.
- Current product catalogue, prices, commissions, joining eligibility, return/refund terms and promotion conditions must be confirmed before launch.
- If information is missing, say: “I don't have a confirmed answer for that yet. Please check with the Nexora team.”

10. ANSWER STYLE
- Be respectful, clear, concise, and beginner-friendly.
- Use PKR/Rs. for currency.
- Distinguish total product profit from a partner's commission.
- Never claim a guaranteed income.
`;
