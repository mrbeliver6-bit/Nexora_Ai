# Nexora Assistant Telegram Bot — Starter Project

This is a starter Telegram AI bot using a Cloudflare Worker webhook and Google's Gemini API. It includes an editable Nexora knowledge base.

## Cost note
Telegram bot creation is free. Cloudflare Workers and Gemini may have free tiers subject to current eligibility, quotas, terms, and regional/model availability. This project does **not** guarantee unlimited, permanently free AI conversations. Check each provider's current limits before public launch. GitHub stores code but does not run the bot by itself.

## 1. Create your Telegram bot
1. Open Telegram and message the official `@BotFather`.
2. Send `/newbot` and follow the prompts.
3. Save the token privately. Never commit it to GitHub or share it in screenshots.

## 2. Get an AI API key
1. Open https://aistudio.google.com/ and check whether Gemini API access is available to your account/region.
2. Create an API key if available.
3. Review current free-tier quotas and terms. Do not assume unlimited usage.

## 3. Upload files to GitHub
Create a new repository and upload `worker.js`, `knowledge_base.js`, `wrangler.toml`, `.gitignore`, and `README.md`. Never upload API keys, bot tokens, or private user/customer data.

## 4. Deploy the Worker
1. Sign in at https://dash.cloudflare.com/.
2. Create a Worker connected to your GitHub repository (the dashboard labels may change).
3. Deploy using `wrangler.toml`.
4. Add these Worker **secrets** in Settings:
   - `TELEGRAM_BOT_TOKEN` — token from BotFather
   - `GEMINI_API_KEY` — key from Google AI Studio
   - `WEBHOOK_SECRET` — a long random string made only of letters, numbers, `_`, and `-`
5. Optional variable: `GEMINI_MODEL` (default `gemini-2.5-flash`). If unavailable, choose a currently supported model in your API account.

## 5. Register Telegram webhook
After deploying and saving secrets, open this URL in your browser, replacing the placeholders:

`https://YOUR-WORKER-SUBDOMAIN.workers.dev/setup?key=YOUR_WEBHOOK_SECRET`

The URL contains your secret. Do not share it or post it in screenshots. A JSON response should indicate whether Telegram accepted the webhook.

## 6. Test
Open the bot in Telegram and send `/start`, `/about`, `/products`, `/levels`, and normal questions such as “How do I join?” or “What is the current return policy?” The bot should admit when information is not confirmed.

## Edit company information
Update `knowledge_base.js` whenever official information changes, then commit/push and redeploy. This starter knowledge base includes historical planning details that must be verified before launch.

## Limitations and safety
- The bot is informational only; it does not access Markaz, register partners, track orders, verify payments, or issue refunds.
- It has no persistent per-user conversation memory; each AI answer uses the knowledge base plus the current question.
- AI can make mistakes. Verify prices, commissions, and policies before public launch.
- Free quotas, provider availability, and terms can change.
- Do not put supplier costs, internal order records, customer data, or partner personal data in the public knowledge base.
